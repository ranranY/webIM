//index.js
//获取应用实例
var webim = require('../../utils/webim.js');
var webimutils = require('../../utils/webim-utils.js');
var webimhandler = require('../../utils/webim_handler');
var tls = require('../../utils/tls.js');

global.webim = webim;

var app = getApp()
//当前会话的session
let selSess = null;
//聊天用户信息
let loginInfo = {}
Page({
  data: {
    userInfo: {},
    msgs: [],
    Identifier: null,
    UserSig: null,
	isText:true,//默认发送文字消息；
    msgContent: ""
  },

  clearInput: function () {
    this.setData({
      msgContent: ""
    })
  },

  bindConfirm: function (e) {
    var that = this;
    var content = e.detail.value;
    if (!content.replace(/^\s*|\s*$/g, '')) return;

    webimutils.onSendMsg(content, function (msg) {
      that.showMsg(msg)
      that.clearInput();
    })


  },

  //显示聊天信息到页面
  showMsg: function (msg) {
    var self = this;
    console.info('----msg-----')
    console.info(msg)
	
    //根据用户唯一id获取用户信息
    var userInfo = app.findUserInfoByIdentifier(msg.fromAccount);
    msg.nickName = userInfo.nickName;
	msg.isText = true;
	msg.isImg = false;
    msg.sess = null; //有循环引用
    this.data.msgs.push(msg);
	this.checkMsgType(this.data.msgs);// 检测用户发送的是图片消息还是文字消息：
    this.setData({
      msgs: this.data.msgs
    })
  },
//   检测用户发送的消息类型：
checkMsgType:function(msgsArr){
	// 检测用户发送的是图片消息还是文字消息：
	for (var i = 0; i < msgsArr.length; i++) {
		var itemMsg = msgsArr[i];
		console.log("********itemMsg******")
		console.log(itemMsg)
		var sendType = itemMsg.elems[0].type;
		itemMsg.time = app.ms2str(itemMsg.time);
		if (sendType == "TIMImageElem") {//用户发送的是图片消息
			itemMsg.isImg = true;
			itemMsg.isText = false;
		} else if (sendType == "TIMTextElem") {//用户发送的是文字消息；
			itemMsg.isImg = false;
			itemMsg.isText = true;
		}
	}
},
  //显示历史聊天信息到页面
  showHistoryMsg: function (msg) {
    var self = this;
	console.info('----显示历史聊天信息到页面-----')
    console.info(msg)
    //根据用户唯一id获取用户信息
    var userInfo = app.findUserInfoByIdentifier(msg.fromAccount);
    msg.nickName = userInfo.nickName;
    msg.sess = null; //有循环引用
    this.data.msgs.unshift(msg);
	this.checkMsgType(this.data.msgs);// 检测用户发送的是图片消息还是文字消息：
    this.setData({
      msgs: this.data.msgs
    })
  },


//   获取历史消息记录：
  getHistory : function(){
    var self = this;
    var options = {
      'Peer_Account': app.data.toFriend, //好友帐号
      'MaxCnt': app.data.msgPageSie, //拉取消息条数
      'LastMsgTime': app.data.lastMsgTime, //最近的消息时间，即从这个时间点向前拉取历史消息
      'MsgKey': app.data.msgKey
    };
    webim.getC2CHistoryMsgs(
      options,
      function (resp) {
        console.info('------getC2CHistoryMsgs-resp-------')
        console.info(resp)
        self.showHistoryMsgList(resp.MsgList)
        var complete = resp.Complete;//是否还有历史消息可以拉取，1-表示没有，0-表示有
        var retMsgCount = resp.MsgCount;//返回的消息条数，小于或等于请求的消息条数，小于的时候，说明没有历史消息可拉取了
        if (resp.MsgList.length == 0) {
          console.info("没有历史消息了:data=" + JSON.stringify(options));
          return;
        }
        ////保留服务器返回的最近消息时间和消息Key,用于下次向前拉取历史消息
        app.data.lastMsgTime = resp.LastMsgTime;
        app.data.msgKey = resp.MsgKey;
      }
    );
  },
  
  showHistoryMsgList : function(msgList){
    //将历史信息反转
    msgList = msgList.reverse();
    var self = this;
    if (msgList != null && msgList.length > 0) {
      msgList.forEach(function(o, i){
        self.showHistoryMsg(o)
      })
    }
    
  },

//   获取用户未读消息：
UnreadMsg:function(){
	var sessMap = webim.MsgStore.sessMap();//获取全局sessMap；
	var unreadNum = sessMap["C2CID" + app.data.Identifier].unread();
	console.log('获取用户未读消息：')
	console.log(unreadNum)
},

//   用户发表图片消息：
	ImageMsg:function(resp){
		var that = this;
		wx.chooseImage({
			count: 1, // 默认9
			sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
			sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
			success: function (res) {
				// 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
				console.info('-res---')
				console.log(res)
				var images = res.tempFiles;
				if (images != null && images.length > 0) {
					images.forEach(function(o){
						var img = {};
						img.url = o.path;
						img.size = o.size;
						wx.getImageInfo({
							src: o.path,
							success : function(resp){
								img.width = resp.width;
								img.height = resp.height;
								img.type = resp.type;
								img.uuid='hsjkfhsjkdhfjkdshfjksdfjkd'
								console.info('---img---')
								console.info(img);
								webimutils.sendPic(img, function (msg) {
									console.log("*************msg*********")
									console.log(msg)
									that.showMsg(msg)
								})
							}
						})
					})
				}
				
			}
		})
		console.log(resp)
	},

	//   下拉加载用户聊天记录：
	onPullDownRefresh:function(){
		console.log("下拉加载用户聊天记录：")
		this.getHistory();
	},

    // 结束本次聊天：
	sessionEnd:function(){
		console.log("********结束本次聊天：**********")
		var type = webim.SESSION_TYPE.C2C;
		var id = app.data.toFriend;
		console.log(webim.MsgStore.delSessByTypeId(type, id))
		
	},
  
  //初始化聊天
  initIM: function () {
    var that = this;
    //当前用户身份
    loginInfo = {
      'sdkAppID': app.data.sdkAppId, //用户所属应用id,必填
      'appIDAt3rd': app.data.sdkAppId, //用户所属应用id，必填
      'accountType': app.data.accountType, //用户所属应用帐号类型，必填
      'identifier': app.data.Identifier, //当前用户ID,必须是否字符串类型，选填
      'identifierNick': app.data.userInfo.nickName, //当前用户昵称，选填
      'userSig': app.data.UserSig, //当前用户身份凭证，必须是字符串类型，选填
    };
    

    //初始化webim工具类
    webimutils.init({
      loginInfo: loginInfo
    });

    //监听事件
    var listeners = {
      //监听网络状态
      onConnNotify: function(resp){
        switch (resp.ErrorCode) {
          case webim.CONNECTION_STATUS.ON:
            //webim.Log.warn('连接状态正常...');
            break;
          case webim.CONNECTION_STATUS.OFF:
            webim.Log.warn('连接已断开，无法收到新消息，请检查下你的网络是否正常');
            break;
          default:
            webim.Log.error('未知连接状态,status=' + resp.ErrorCode);
            break;
        }
      },
      //收到新消息的触发
      onMsgNotify : function (newMsgList){
        console.info('-------onMsgNotify---------')
        console.info(newMsgList)
        var newMsg;
        for (var j in newMsgList) {//遍历新消息
          newMsg = newMsgList[j];
          that.showMsg(newMsg)
        }
      }
    };

    //其他对象，选填
    var options = {
      'isAccessFormalEnv': true,//是否访问正式环境，默认访问正式，选填
      'isLogOn': false//是否开启控制台打印日志,默认开启，选填
    };

    //web sdk 登录
    webim.login(loginInfo, listeners, options,
      function (identifierNick) {
        //identifierNick为登录用户昵称(没有设置时，为帐号)，无登录态时为空
        console.info('---webim登录成功---')
        
      },
      function (err) {
        console.error(err.ErrorInfo);
      }
    );
  },
  //监听所有的请求
  listenAllSession : function(){
    var self = this;
    setInterval(function(){
      console.info('------listenAllSession------')
      //拿到所有的session
      var sessMap = webim.MsgStore.sessMap();
      //总共有多少session
      var sessCount = webim.MsgStore.sessCount();
      console.info(sessMap)
      var sessionSize = 0;
      for (var key in sessMap) {
        console.info('key-->' + key)
      }
      console.info('sessCount-->' + sessCount)

      //拿到某个用户收到的聊天请求
      var session = webim.MsgStore.sessByTypeId(webim.SESSION_TYPE.C2C ,app.data.toFriend);
      console.info('session-->')
      console.info(session)

    }, 1000);
  },
  
  onLoad: function () {
    // this.listenAllSession();
    var self = this;
    //登录的代码，拿到Identifier和UserSig
    tls.login({
      success: function (data) {
        app.data.UserSig = data.UserSig;
        self.initIM();
      }
    });
  }
})