var webim = require('webim.js');

//聊天的session会话
let selSess = null;
let loginInfo = {}
let app = getApp();

function init(opts) {
  loginInfo = opts.loginInfo;
}

/**
 * 发送文字信息
 * content:发送的消息
 * callback：消息发送成功之后的回调
 */
function onSendMsg(content, callback) {
  var selToID = app.data.toFriend;   //发给谁
  var selToNickName = app.data.toFirendNickName;
  var selSessHeadUrl = app.data.toFirendHeadUrl; //对方的头像
  var selType = webim.SESSION_TYPE.C2C;  //私聊

  console.info('---selSessHeadUrl--->' + selSessHeadUrl)
  console.info('---selToNickName--->' + selToNickName)

  if (!selSess) {
    console.info('---创建 session---')
    selSess = new webim.Session(selType, selToID, selToNickName, selSessHeadUrl, Math.round(new Date().getTime() / 1000));
    console.info(selSess)
  }
  var isSend = true;//是否为自己发送
  var seq = -1;//消息序列，-1表示sdk自动生成，用于去重
  var random = Math.round(Math.random() * 4294967296);//消息随机数，用于去重
  var msgTime = Math.round(new Date().getTime() / 1000);//消息时间戳
  var subType;//消息子类型
  var sendMsgType = true;
  var subType = webim.C2C_MSG_SUB_TYPE.COMMON;
  console.info('------loginInfo------')
  console.info(loginInfo)
  console.info(loginInfo.identifierNick)

  //核心对象
  var msg = new webim.Msg(selSess, isSend, seq, random, msgTime, loginInfo.identifier, subType, loginInfo.identifierNick);

  var text_obj = new webim.Msg.Elem.Text(content);
  msg.addText(text_obj);

  //核心方法：发送消息
  webim.sendMsg(msg, function (resp) {
    console.info('resp-->')
    console.info(resp)
    console.info("发消息成功");
    callback && callback(msg);

  }, function (err) {
    console.error("发消息失败:" + err.ErrorInfo);
  });
}

/***
 * 发送图片信息：
 * **/
function sendPic(image, callback){
	var selToID = app.data.toFriend;   //发给谁
	var selToNickName = app.data.toFirendNickName;
	var selSessHeadUrl = app.data.toFirendHeadUrl; //对方的头像
	var selType = webim.SESSION_TYPE.C2C;  //私聊
	if (!selToID) {
		console.log("您还没有好友，暂不能聊天");
		return;
	}
	if (!selSess) {
		selSess = new webim.Session(selType, selToID, selToID, selToNickName, selSessHeadUrl,Math.round(new Date().getTime() / 1000));
		console.log(selSess)
	}


	var isSend = true;//是否为自己发送
	var seq = -1;//消息序列，-1表示sdk自动生成，用于去重
	var random = Math.round(Math.random() * 4294967296);//消息随机数，用于去重
	var msgTime = Math.round(new Date().getTime() / 1000);//消息时间戳
	var subType;//消息子类型
	var subType = webim.C2C_MSG_SUB_TYPE.COMMON;

	var msg = new webim.Msg(selSess, isSend, seq, random, msgTime, loginInfo.identifier, subType, loginInfo.identifierNick);
	var images_obj = new webim.Msg.Elem.Images(image.uuid);
	var type = webim.IMAGE_TYPE.SMALL;
	var newImg = new webim.Msg.Elem.Images.Image(type, image.size, image.width,image.height, image.url);
	images_obj.addImage(newImg);
	msg.addImage(images_obj);

	console.log("-----------------msg------------------")
	console.log(msg)
	//调用发送图片接口
	webim.sendMsg(msg, function (resp) {
		console.log("********************resp******************")
		console.log(resp)
		console.info("发消息成功");
		callback && callback(msg);
	}, function (err) {
		console.log(err.ErrorInfo);
	});
}


module.exports = {
  init: init,
  onSendMsg: onSendMsg,
  sendPic: sendPic
}