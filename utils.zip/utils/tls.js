var encrypt = require('encrypt.js');

var app = getApp();

// 调用后台接口上传用户id，appID获取用户签名；
function login(opts){
    wx.request({
      url: 'https://sxb.qcloud.com/sxb_dev/?svc=doll&cmd=fetchsig', //仅为示例，并非真实的接口地址
        data: {
          "id": app.data.Identifier,
          "appid": app.data.sdkAppId
        },
        method: 'post',
        header: {
             'content-type': 'application/json'
        },
        success: function(res) {
            opts.success && opts.success({
              UserSig: res.data.data.userSig
            });
        },
        fail : function(errMsg){
            opts.error && opts.error(errMsg);
        }
    });
}

module.exports = {
    login : login
};